"""
Provides Incremental version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update Incremental` to change this file.

from incremental import Version

__version__ = Version("Incremental", 24, 7, 2)
__all__ = ["__version__"]
